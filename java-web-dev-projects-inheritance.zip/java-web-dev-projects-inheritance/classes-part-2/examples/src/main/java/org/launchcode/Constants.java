package org.launchcode;

public class Constants {
    public static final double PI = 3.14159;
    public static final String FIRST_PRESIDENT = "George Washington";
}