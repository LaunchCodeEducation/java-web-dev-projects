package org.launchcode;

public class FortyTwo {
    public int intValue = 42;
}
