package exercises.classespart1;

import exercises.classespart2.Teacher;

import java.util.ArrayList;

public class Course {
        private String topic;
        private Teacher instructor;
        private ArrayList<Student> enrolledStudents;
    }
}
