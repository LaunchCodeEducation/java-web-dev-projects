public class StudentPractice {
    public static void main(String[] args){
        //insantiate your Student class below
    }
}
