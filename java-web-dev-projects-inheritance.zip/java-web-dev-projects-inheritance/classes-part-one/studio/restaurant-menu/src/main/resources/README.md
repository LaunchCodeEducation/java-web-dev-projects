Resources directory for Restaurant-Menu studio
