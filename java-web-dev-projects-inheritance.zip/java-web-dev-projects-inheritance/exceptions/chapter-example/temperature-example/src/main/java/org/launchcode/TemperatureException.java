package org.launchcode;

public class TemperatureException {
    // Write code here!
}
